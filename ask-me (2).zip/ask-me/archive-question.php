<?php get_header();
	global $vbegy_sidebar_all;
	$blog_style = vpanel_options("home_display");
	query_posts(array("post_type" => "question","meta_query" => array(array("key" => "user_id","compare" => "NOT EXISTS"))));
	get_template_part("loop-question","archive");
	vpanel_pagination();
	wp_reset_query();
get_footer();?>